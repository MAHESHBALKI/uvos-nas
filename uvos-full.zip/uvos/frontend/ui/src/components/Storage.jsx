import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';

const Storage = () => {
  const [pools, setPools] = useState([]);
  const [disks, setDisks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    type: 'stripe',
    devices: []
  });
  const { authFetch, user } = useAuth();

  useEffect(() => {
    fetchStorageData();
  }, []);

  const fetchStorageData = async () => {
    try {
      setLoading(true);
      const [poolsResponse, disksResponse] = await Promise.all([
        authFetch('/api/storage/pools'),
        authFetch('/api/disks')
      ]);

      if (!poolsResponse.ok) throw new Error('Failed to fetch pools');
      if (!disksResponse.ok) throw new Error('Failed to fetch disks');

      const poolsData = await poolsResponse.json();
      const disksData = await disksResponse.json();

      setPools(poolsData.pools || []);
      setDisks(disksData.disks?.blockdevices || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePool = async (e) => {
    e.preventDefault();
    if (!user?.admin) {
      setError('Only administrators can create storage pools');
      return;
    }

    try {
      const response = await authFetch('/api/storage/pools', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Failed to create pool');
      }

      setShowCreateForm(false);
      setFormData({ name: '', type: 'stripe', devices: [] });
      fetchStorageData(); // Refresh the list
      setError('');
    } catch (err) {
      setError(err.message);
    }
  };

  const handleDeviceToggle = (deviceName) => {
    setFormData(prev => ({
      ...prev,
      devices: prev.devices.includes(deviceName)
        ? prev.devices.filter(d => d !== deviceName)
        : [...prev.devices, `/dev/${deviceName}`]
    }));
  };

  if (loading) return <div className="storage">Loading storage information...</div>;

  return (
    <div className="storage">
      <h1>Storage Management</h1>
      {error && <div className="error">{error}</div>}

      {/* Create Pool Section - Only for admins */}
      {user?.admin && (
        <div className="section">
          <h2>Create Storage Pool</h2>
          {!showCreateForm ? (
            <button 
              className="btn-primary" 
              onClick={() => setShowCreateForm(true)}
            >
              Create New Pool
            </button>
          ) : (
            <form onSubmit={handleCreatePool} className="create-pool-form">
              <h3>Create New ZFS Pool</h3>
              
              <div>
                <label>Pool Name:</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="e.g., tank, storage"
                  required
                  pattern="[a-zA-Z0-9_-]{1,50}"
                />
              </div>

              <div>
                <label>Pool Type:</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({...formData, type: e.target.value})}
                >
                  <option value="stripe">Stripe (No redundancy)</option>
                  <option value="mirror">Mirror (Redundancy)</option>
                  <option value="raidz1">RAID-Z1 (Single parity)</option>
                  <option value="raidz2">RAID-Z2 (Double parity)</option>
                </select>
              </div>

              <div>
                <label>Select Devices:</label>
                <div className="disks-list">
                  {disks
                    .filter(disk => disk.type === 'disk' && !disk.mountpoint)
                    .map(disk => (
                      <div key={disk.name} className="disk-item">
                        <input
                          type="checkbox"
                          id={disk.name}
                          checked={formData.devices.includes(`/dev/${disk.name}`)}
                          onChange={() => handleDeviceToggle(disk.name)}
                        />
                        <label htmlFor={disk.name}>
                          {disk.name} - {disk.size} {disk.model && `- ${disk.model}`}
                        </label>
                      </div>
                    ))
                  }
                </div>
              </div>

              <button type="submit" disabled={formData.devices.length === 0}>
                Create Pool
              </button>
              <button 
                type="button" 
                onClick={() => setShowCreateForm(false)}
                style={{marginLeft: '10px'}}
              >
                Cancel
              </button>
            </form>
          )}
        </div>
      )}

      {/* Existing Pools Section */}
      <div className="section">
        <h2>Existing Storage Pools</h2>
        {pools.length === 0 ? (
          <p>No storage pools configured.</p>
        ) : (
          <div className="pools-list">
            {pools.map(pool => (
              <div key={pool.name} className="pool-item">
                <h4>{pool.name}</h4>
                <p>Size: {pool.size}</p>
                <p>Free: {pool.free}</p>
                <p>Health: <strong>{pool.health}</strong></p>
                {pool.mountpoint && <p>Mount: {pool.mountpoint}</p>}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Available Disks Section */}
      <div className="section">
        <h2>Available Disks</h2>
        <div className="disks-grid">
          {disks
            .filter(disk => disk.type === 'disk')
            .map(disk => (
              <div key={disk.name} className="disk-card">
                <h4>/dev/{disk.name}</h4>
                <p>Size: {disk.size}</p>
                <p>Model: {disk.model || 'N/A'}</p>
                <p>Type: {disk.rota === '1' ? 'HDD' : 'SSD'}</p>
                {disk.mountpoint && <p>Mounted: {disk.mountpoint}</p>}
              </div>
            ))
          }
        </div>
      </div>
    </div>
  );
};

export default Storage;