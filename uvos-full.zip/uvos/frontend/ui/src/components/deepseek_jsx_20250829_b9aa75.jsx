import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';

const Users = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    email: '',
    full_name: '',
    admin: false,
    disabled: false
  });
  const { authFetch, user } = useAuth();

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await authFetch('/api/users');
      if (!response.ok) throw new Error('Failed to fetch users');
      const usersData = await response.json();
      setUsers(usersData);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateUser = async (e) => {
    e.preventDefault();
    try {
      const response = await authFetch('/api/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail?.message || 'Failed to create user');
      }

      const newUser = await response.json();
      setUsers([...users, newUser]);
      setShowCreateForm(false);
      setFormData({
        username: '', password: '', email: '', full_name: '', admin: false, disabled: false
      });
      setError('');
    } catch (err) {
      setError(err.message);
    }
  };

  if (loading) return <div className="users">Loading users...</div>;
  if (!user?.admin) return <div className="users">Access denied. Administrator privileges required.</div>;

  return (
    <div className="users">
      <h1>User Management</h1>
      {error && <div className="error">{error}</div>}

      <div className="create-user-form">
        <h3>Create New User</h3>
        {!showCreateForm ? (
          <button 
            className="btn-primary" 
            onClick={() => setShowCreateForm(true)}
          >
            Add New User
          </button>
        ) : (
          <form onSubmit={handleCreateUser}>
            <div>
              <label>Username:</label>
              <input
                type="text"
                value={formData.username}
                onChange={(e) => setFormData({...formData, username: e.target.value})}
                required
                pattern="[a-zA-Z0-9_-]{3,20}"
              />
            </div>

            <div>
              <label>Password:</label>
              <input
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
                required
                minLength="8"
              />
            </div>

            <div>
              <label>Email:</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
              />
            </div>

            <div>
              <label>Full Name:</label>
              <input
                type="text"
                value={formData.full_name}
                onChange={(e) => setFormData({...formData, full_name: e.target.value})}
              />
            </div>

            <div className="checkbox-group">
              <label>
                <input
                  type="checkbox"
                  checked={formData.admin}
                  onChange={(e) => setFormData({...formData, admin: e.target.checked})}
                />
                Administrator
              </label>
            </div>

            <div className="checkbox-group">
              <label>
                <input
                  type="checkbox"
                  checked={formData.disabled}
                  onChange={(e) => setFormData({...formData, disabled: e.target.checked})}
                />
                Disabled
              </label>
            </div>

            <button type="submit">Create User</button>
            <button 
              type="button" 
              onClick={() => setShowCreateForm(false)}
              style={{marginLeft: '10px'}}
            >
              Cancel
            </button>
          </form>
        )}
      </div>

      <div className="users-list">
        <h2>System Users</h2>
        <table>
          <thead>
            <tr>
              <th>Username</th>
              <th>Email</th>
              <th>Full Name</th>
              <th>Role</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {users.map(user => (
              <tr key={user.username}>
                <td>{user.username}</td>
                <td>{user.email || 'N/A'}</td>
                <td>{user.full_name || 'N/A'}</td>
                <td>
                  <span className={`role-badge ${user.admin ? 'admin' : 'user'}`}>
                    {user.admin ? 'Administrator' : 'User'}
                  </span>
                </td>
                <td>
                  <span className={`status-badge ${user.disabled ? 'disabled' : 'active'}`}>
                    {user.disabled ? 'Disabled' : 'Active'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Users;