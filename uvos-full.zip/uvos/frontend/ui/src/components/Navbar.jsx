import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Navbar = () => {
  const { user, logout } = useAuth();
  const location = useLocation();

  const isActive = (path) => location.pathname === path;

  return (
    <nav className="navbar">
      <div className="navbar-brand">
        <h2>UVOS NAS</h2>
      </div>
      
      <div className="navbar-menu">
        <Link to="/" className={isActive('/') ? 'active' : ''}>
          Dashboard
        </Link>
        <Link to="/storage" className={isActive('/storage') ? 'active' : ''}>
          Storage
        </Link>
        {user?.admin && (
          <Link to="/users" className={isActive('/users') ? 'active' : ''}>
            Users
          </Link>
        )}
      </div>

      <div className="navbar-user">
        <span className="welcome-text">
          Welcome, <strong>{user?.username}</strong>
          {user?.admin && <span className="admin-badge">ADMIN</span>}
        </span>
        <button onClick={logout} className="logout-btn">
          Logout
        </button>
      </div>
    </nav>
  );
};

export default Navbar;