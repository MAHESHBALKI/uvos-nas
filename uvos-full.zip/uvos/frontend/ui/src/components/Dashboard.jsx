import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';

const Dashboard = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const { authFetch } = useAuth();

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const response = await authFetch('/api/system/stats');
      if (!response.ok) throw new Error('Failed to fetch stats');
      const data = await response.json();
      setStats(data.stats);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="dashboard">Loading...</div>;
  if (error) return <div className="dashboard">Error: {error}</div>;

  return (
    <div className="dashboard">
      <h1>System Dashboard</h1>
      
      <div className="stats-grid">
        <div className="stat-card">
          <h3>Memory Usage</h3>
          <p>Total: {(stats.memory.total / 1024 / 1024 / 1024).toFixed(2)} GB</p>
          <p>Used: {(stats.memory.used / 1024 / 1024 / 1024).toFixed(2)} GB</p>
          <div className="progress-bar">
            <div 
              className="progress-fill" 
              style={{width: `${stats.memory.percent}%`}}
            ></div>
          </div>
          <p>{stats.memory.percent}% Used</p>
        </div>

        <div className="stat-card">
          <h3>CPU Usage</h3>
          <p>Overall: {stats.cpu.percent}%</p>
          <p>User: {stats.cpu.user}%</p>
          <p>System: {stats.cpu.system}%</p>
        </div>

        <div className="stat-card">
          <h3>Disk Usage</h3>
          <p>Total: {(stats.disk.total / 1024 / 1024 / 1024).toFixed(2)} GB</p>
          <p>Used: {(stats.disk.used / 1024 / 1024 / 1024).toFixed(2)} GB</p>
          <div className="progress-bar">
            <div 
              className="progress-fill" 
              style={{width: `${stats.disk.percent}%`}}
            ></div>
          </div>
          <p>{stats.disk.percent}% Used</p>
        </div>

        <div className="stat-card">
          <h3>System Uptime</h3>
          <p>{Math.floor(stats.uptime / 3600)} hours</p>
          <p>{Math.floor((stats.uptime % 3600) / 60)} minutes</p>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;