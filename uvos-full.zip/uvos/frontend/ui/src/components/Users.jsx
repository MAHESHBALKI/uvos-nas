import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';

const Users = () => {
  const [users, setUsers] = useState([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newUser, setNewUser] = useState({
    username: '',
    password: '',
    email: '',
    full_name: '',
    disabled: false,
    admin: false
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { fetchWithAuth, user } = useAuth();

  // Admin permission check
  if (!user?.admin) {
    return (
      <div className="users">
        <h1>User Management</h1>
        <div className="error">Access denied. Administrator privileges required.</div>
      </div>
    );
  }

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await fetchWithAuth('/api/users');
      if (response.ok) {
        const data = await response.json();
        setUsers(data);
      } else {
        console.error('Failed to fetch users');
      }
    } catch (error) {
      console.error('Failed to fetch users:', error);
    }
  };

  const handleCreateUser = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await fetchWithAuth('/api/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newUser),
      });

      if (response.ok) {
        setShowCreateForm(false);
        setNewUser({
          username: '',
          password: '',
          email: '',
          full_name: '',
          disabled: false,
          admin: false
        });
        fetchUsers(); // Refresh the list
      } else {
        const errorData = await response.json();
        setError(errorData.error?.message || 'Failed to create user');
      }
    } catch (error) {
      setError('Failed to create user');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field, value) => {
    setNewUser(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <div className="users">
      <h1>User Management</h1>
      
      <button 
        onClick={() => setShowCreateForm(!showCreateForm)}
        className="btn-primary"
      >
        {showCreateForm ? 'Cancel' : 'Create New User'}
      </button>

      {showCreateForm && (
        <div className="create-user-form">
          <h3>Create New User</h3>
          {error && <div className="error">{error}</div>}
          <form onSubmit={handleCreateUser}>
            <div className="form-group">
              <label>Username:</label>
              <input
                type="text"
                value={newUser.username}
                onChange={(e) => handleInputChange('username', e.target.value)}
                required
                disabled={loading}
              />
            </div>
            <div className="form-group">
              <label>Password:</label>
              <input
                type="password"
                value={newUser.password}
                onChange={(e) => handleInputChange('password', e.target.value)}
                required
                disabled={loading}
              />
            </div>
            <div className="form-group">
              <label>Email:</label>
              <input
                type="email"
                value={newUser.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                disabled={loading}
              />
            </div>
            <div className="form-group">
              <label>Full Name:</label>
              <input
                type="text"
                value={newUser.full_name}
                onChange={(e) => handleInputChange('full_name', e.target.value)}
                disabled={loading}
              />
            </div>
            <div className="form-group checkbox-group">
              <label>
                <input
                  type="checkbox"
                  checked={newUser.admin}
                  onChange={(e) => handleInputChange('admin', e.target.checked)}
                  disabled={loading}
                />
                Administrator
              </label>
            </div>
            <div className="form-group checkbox-group">
              <label>
                <input
                  type="checkbox"
                  checked={newUser.disabled}
                  onChange={(e) => handleInputChange('disabled', e.target.checked)}
                  disabled={loading}
                />
                Disabled
              </label>
            </div>
            <button type="submit" disabled={loading} className="btn-primary">
              {loading ? 'Creating...' : 'Create User'}
            </button>
          </form>
        </div>
      )}

      <div className="users-list">
        <h2>System Users</h2>
        {users.length === 0 ? (
          <p>No users found.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Username</th>
                <th>Email</th>
                <th>Full Name</th>
                <th>Role</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {users.map(user => (
                <tr key={user.username}>
                  <td>{user.username}</td>
                  <td>{user.email || '-'}</td>
                  <td>{user.full_name || '-'}</td>
                  <td>
                    <span className={`role-badge ${user.admin ? 'admin' : 'user'}`}>
                      {user.admin ? 'Administrator' : 'User'}
                    </span>
                  </td>
                  <td>
                    <span className={`status-badge ${user.disabled ? 'disabled' : 'active'}`}>
                      {user.disabled ? 'Disabled' : 'Active'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default Users;