#!/bin/bash
# deploy.sh - Enhanced production deployment script with health checks

set -e

# Load environment variables
if [ -f .env ]; then
    export $(cat .env | grep -v '^#' | xargs)
fi

# Validate required environment variables
required_vars=("SECRET_KEY" "REFRESH_SECRET_KEY" "HOST_AGENT_SECRET")
for var in "${required_vars[@]}"; do
    if [ -z "${!var}" ]; then
        echo "ERROR: $var must be set in .env file"
        exit 1
    fi
done

# Create data and log directories
mkdir -p data/{storage,redis}
sudo mkdir -p /var/log/uvos
sudo chown -R ${HOST_API_UID:-1000}:${HOST_UVOS_GID} /var/log/uvos
sudo chmod 755 /var/log/uvos

# Create uvos group if it doesn't exist
if ! getent group uvos >/dev/null; then
    sudo groupadd uvos
    echo "Created group 'uvos'"
fi

# Get numeric group ID for uvos group
UVOS_GID=$(getent group uvos | cut -d: -f3)
if [ -z "$UVOS_GID" ]; then
    echo "ERROR: Failed to get GID for uvos group"
    exit 1
fi

# Update .env with numeric IDs
if ! grep -q "HOST_UVOS_GID" .env 2>/dev/null; then
    echo "HOST_UVOS_GID=$UVOS_GID" >> .env
fi

if ! grep -q "HOST_API_UID" .env 2>/dev/null; then
    echo "HOST_API_UID=1000" >> .env
fi

# Install and configure host agent
if [ ! -d "/opt/uvos/host_agent" ]; then
    sudo mkdir -p /opt/uvos/host_agent
    sudo cp host_agent/agent.py /opt/uvos/host_agent/
    sudo cp host_agent/redis_sync.py /opt/uvos/host_agent/
    sudo cp host_agent/uvos-agent.service /etc/systemd/system/
    sudo cp host_agent/uvos-agent.socket /etc/systemd/system/
    sudo systemctl daemon-reload
    sudo systemctl enable uvos-agent.socket
    sudo systemctl enable uvos-agent.service
    sudo systemctl start uvos-agent.socket
    sudo systemctl start uvos-agent.service
fi

# Ensure socket permissions are correct
if [ -S "/var/run/uvos-agent.sock" ]; then
    sudo chown root:uvos /var/run/uvos-agent.sock
    sudo chmod 660 /var/run/uvos-agent.sock
fi

# Build and deploy
docker-compose down
docker-compose build
docker-compose up -d

# Wait for services to start
echo "Waiting for services to start..."
sleep 10

# Health check
echo "Performing health check..."
API_URL="http://localhost:8000/api/health"
if command -v curl >/dev/null 2>&1; then
    HEALTH_RESPONSE=$(curl -s $API_URL || echo "{}")
    API_STATUS=$(echo $HEALTH_RESPONSE | grep -o '"api":true' || true)
    
    if [ -n "$API_STATUS" ]; then
        echo "Health check passed: API is responding"
    else
        echo "WARNING: Health check failed or API not responding"
        echo "Response: $HEALTH_RESPONSE"
    fi
else
    echo "curl not available, skipping health check"
fi

echo "Deployment completed successfully!"
echo "Access your UVOS instance at: https://uvos.local"