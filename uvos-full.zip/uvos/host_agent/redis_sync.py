import redis
import os
import logging

logger = logging.getLogger("host-agent")

# Configuration for Redis failure behavior
REDIS_FAIL_OPEN = os.environ.get("REDIS_FAIL_OPEN", "true").lower() == "true"

def get_redis_sync():
    """Get a synchronous Redis connection"""
    url = os.environ.get("REDIS_URL", "redis://127.0.0.1:6379/0")
    try:
        client = redis.from_url(url, decode_responses=True)
        client.ping()
        return client
    except Exception as e:
        logger.error(f"Redis sync connection failed: {e}")
        return None

def is_nonce_seen_sync(nonce: str, window: int = 30) -> bool:
    """Check if nonce has been seen using synchronous Redis"""
    r = get_redis_sync()
    
    # If Redis is unavailable, use fail-open/fail-close behavior
    if r is None:
        logger.warning(f"Redis unavailable, using fail-{'open' if REDIS_FAIL_OPEN else 'closed'} behavior")
        return not REDIS_FAIL_OPEN  # True if fail-closed (reject), False if fail-open (allow)
    
    key = f"nonce:{nonce}"
    # SET NX with expiry; returns True if set (new), None if exists
    try:
        result = r.set(key, 1, ex=window, nx=True)
        return result is not True  # True means it was set (new), False means it exists
    except Exception as e:
        logger.error(f"Redis error in sync nonce check: {e}")
        return not REDIS_FAIL_OPEN  # True if fail-closed (reject), False if fail-open (allow)