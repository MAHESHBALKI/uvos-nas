import socket
import json
import subprocess
import logging
import os
import time
import grp
import re
from pathlib import Path
from typing import Dict, Any

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("host-agent")

SOCKET_PATH = "/var/run/uvos-agent.sock"
SOCKET_GROUP = "uvos"
SOCKET_MODE = 0o660

class HostAgent:
    def __init__(self):
        self.socket_path = SOCKET_PATH
        self.socket_group = SOCKET_GROUP
        self.socket_mode = SOCKET_MODE
        self.secret = os.environ.get("HOST_AGENT_SECRET")
        self.command_handlers = {
            "zpool_create": self.handle_zpool_create,
            "zpool_list": self.handle_zpool_list,
            "zfs_list": self.handle_zfs_list,
            "zfs_snapshot": self.handle_zfs_snapshot,
            "zfs_destroy": self.handle_zfs_destroy,
        }
    
    def set_socket_permissions(self):
        """Set proper permissions on the socket file"""
        try:
            # Get group ID
            group_info = grp.getgrnam(self.socket_group)
            gid = group_info.gr_gid
            
            # Change group ownership
            Path(self.socket_path).chown(-1, gid)
            
            # Set permissions
            Path(self.socket_path).chmod(self.socket_mode)
            
            logger.info(f"Set socket permissions to group {self.socket_group} with mode {oct(self.socket_mode)}")
            
        except KeyError:
            logger.error(f"Group {self.socket_group} does not exist")
            # Create the group if it doesn't exist
            subprocess.run(["groupadd", self.socket_group], check=False)
            logger.info(f"Created group {self.socket_group}")
            
            # Try again
            try:
                group_info = grp.getgrnam(self.socket_group)
                gid = group_info.gr_gid
                Path(self.socket_path).chown(-1, gid)
                Path(self.socket_path).chmod(self.socket_mode)
            except Exception as e:
                logger.error(f"Failed to set socket permissions: {e}")
        except Exception as e:
            logger.error(f"Failed to set socket permissions: {e}")
    
    def verify_request(self, request: dict) -> bool:
        """Verify request authentication with nonce using synchronous Redis"""
        if not self.secret:
            logger.warning("No HOST_AGENT_SECRET set, allowing all requests (insecure!)")
            return True
        
        token = request.get("token")
        timestamp = request.get("timestamp")
        nonce = request.get("nonce")
        
        if not token or not timestamp or not nonce:
            logger.warning("Missing authentication fields in request")
            return False
        
        # Check if timestamp is recent first (before Redis call)
        current_time = time.time()
        if abs(current_time - timestamp) > 30:
            logger.warning(f"Timestamp {timestamp} is too old (current: {current_time})")
            return False
        
        # Verify HMAC
        import hmac
        import hashlib
        
        expected_token = hmac.new(
            self.secret.encode(),
            f"{timestamp}:{nonce}".encode(),
            hashlib.sha256
        ).hexdigest()
        
        if not hmac.compare_digest(token, expected_token):
            logger.warning("HMAC token verification failed")
            return False
        
        # Check if nonce has been seen using synchronous Redis
        from .redis_sync import is_nonce_seen_sync
        if is_nonce_seen_sync(nonce):
            logger.warning(f"Nonce {nonce} has already been used")
            return False
        
        return True

    def handle_zpool_create(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle zpool create command with validation"""
        try:
            pool_name = params.get("name")
            devices = params.get("devices", [])
            pool_type = params.get("type", "stripe")
            
            # Validate inputs
            if not pool_name or not devices:
                return {"success": False, "error": "Missing required parameters"}
            
            # Validate devices exist
            for device in devices:
                if not Path(device).exists():
                    return {"success": False, "error": f"Device {device} does not exist"}
            
            # Build and execute command
            if pool_type == "stripe":
                cmd = ["zpool", "create", "-f", pool_name] + devices
            elif pool_type == "mirror":
                cmd = ["zpool", "create", "-f", pool_name, "mirror"] + devices
            else:
                cmd = ["zpool", "create", "-f", pool_name, pool_type] + devices
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            
            if result.returncode == 0:
                logger.info(f"Successfully created pool '{pool_name}'")
                return {"success": True, "output": result.stdout}
            else:
                sanitized_error = self.sanitize_error_message(result.stderr)
                logger.error(f"Failed to create pool '{pool_name}': {sanitized_error}")
                return {"success": False, "error": "Failed to create storage pool"}
                
        except subprocess.TimeoutExpired:
            logger.error("Zpool create command timed out")
            return {"success": False, "error": "Operation timed out"}
        except Exception as e:
            sanitized_error = self.sanitize_error_message(str(e))
            logger.error(f"Unexpected error creating pool: {sanitized_error}")
            return {"success": False, "error": "Unexpected error"}

    def handle_zpool_list(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle zpool list command"""
        try:
            result = subprocess.run(
                ["zpool", "list", "-H", "-o", "name,size,alloc,free,health,mountpoint"],
                capture_output=True, text=True
            )
            
            if result.returncode == 0:
                pools = []
                for line in result.stdout.strip().split('\n'):
                    if line:
                        parts = line.split('\t')
                        pools.append({
                            "name": parts[0],
                            "size": parts[1],
                            "allocated": parts[2],
                            "free": parts[3],
                            "health": parts[4],
                            "mountpoint": parts[5] if len(parts) > 5 else ""
                        })
                return {"success": True, "pools": pools}
            else:
                return {"success": False, "error": result.stderr}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def handle_zfs_list(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle zfs list command"""
        try:
            result = subprocess.run(
                ["zfs", "list", "-H", "-o", "name,used,available,mountpoint"],
                capture_output=True, text=True
            )
            
            if result.returncode == 0:
                datasets = []
                for line in result.stdout.strip().split('\n'):
                    if line:
                        parts = line.split('\t')
                        datasets.append({
                            "name": parts[0],
                            "used": parts[1],
                            "available": parts[2],
                            "mountpoint": parts[3] if len(parts) > 3 else ""
                        })
                return {"success": True, "datasets": datasets}
            else:
                return {"success": False, "error": result.stderr}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def handle_zfs_snapshot(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle zfs snapshot command"""
        try:
            dataset = params.get("dataset")
            snapshot_name = params.get("name")
            
            if not dataset or not snapshot_name:
                return {"success": False, "error": "Missing dataset or snapshot name"}
            
            cmd = ["zfs", "snapshot", f"{dataset}@{snapshot_name}"]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            
            if result.returncode == 0:
                logger.info(f"Successfully created snapshot '{snapshot_name}' for dataset '{dataset}'")
                return {"success": True, "output": result.stdout}
            else:
                sanitized_error = self.sanitize_error_message(result.stderr)
                logger.error(f"Failed to create snapshot: {sanitized_error}")
                return {"success": False, "error": "Failed to create snapshot"}
                
        except subprocess.TimeoutExpired:
            logger.error("ZFS snapshot command timed out")
            return {"success": False, "error": "Operation timed out"}
        except Exception as e:
            sanitized_error = self.sanitize_error_message(str(e))
            logger.error(f"Unexpected error creating snapshot: {sanitized_error}")
            return {"success": False, "error": "Unexpected error"}
    
    def handle_zfs_destroy(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle zfs destroy command (with caution)"""
        try:
            target = params.get("target")
            recursive = params.get("recursive", False)
            
            if not target:
                return {"success": False, "error": "Missing target"}
            
            cmd = ["zfs", "destroy"]
            if recursive:
                cmd.append("-r")
            cmd.append(target)
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            
            if result.returncode == 0:
                logger.info(f"Successfully destroyed '{target}'")
                return {"success": True, "output": result.stdout}
            else:
                sanitized_error = self.sanitize_error_message(result.stderr)
                logger.error(f"Failed to destroy '{target}': {sanitized_error}")
                return {"success": False, "error": "Failed to destroy target"}
                
        except subprocess.TimeoutExpired:
            logger.error("ZFS destroy command timed out")
            return {"success": False, "error": "Operation timed out"}
        except Exception as e:
            sanitized_error = self.sanitize_error_message(str(e))
            logger.error(f"Unexpected error destroying target: {sanitized_error}")
            return {"success": False, "error": "Unexpected error"}
    
    def process_request(self, request_data: str) -> str:
        """Process a JSON request and return JSON response"""
        try:
            request = json.loads(request_data)
            
            # Verify authentication
            if not self.verify_request(request):
                return json.dumps({"success": False, "error": "Authentication failed"})
            
            command = request.get("command")
            params = request.get("params", {})
            
            if command in self.command_handlers:
                result = self.command_handlers[command](params)
                return json.dumps(result)
            else:
                return json.dumps({"success": False, "error": f"Unknown command: {command}"})
                
        except json.JSONDecodeError:
            return json.dumps({"success": False, "error": "Invalid JSON")
        except Exception as e:
            return json.dumps({"success": False, "error": str(e)})
    
    def sanitize_error_message(self, error_msg: str) -> str:
        """Sanitize error messages to remove sensitive information"""
        if not error_msg:
            return error_msg
        
        # Remove device paths
        sanitized = re.sub(r'/dev/[a-zA-Z0-9_/-]+', '/dev/XXX', error_msg)
        
        # Remove pool names (could be sensitive)
        sanitized = re.sub(r"pool '[a-zA-Z0-9_-]+'", "pool 'XXX'", sanitized)
        
        # Remove dataset names
        sanitized = re.sub(r"dataset '[a-zA-Z0-9_/-]+'", "dataset 'XXX'", sanitized)
        
        # Remove IP addresses
        sanitized = re.sub(r'\d+\.\d+\.\d+\.\d+', 'XXX.XXX.XXX.XXX', sanitized)
        
        return sanitized

    def run(self):
        """Run the host agent server"""
        # Remove socket if it already exists
        if Path(self.socket_path).exists():
            Path(self.socket_path).unlink()
        
        # Create UNIX socket server
        server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        server.bind(self.socket_path)
        
        # Set socket permissions
        self.set_socket_permissions()
        
        server.listen(1)
        
        logger.info(f"Host agent listening on {self.socket_path}")
        
        try:
            while True:
                conn, addr = server.accept()
                try:
                    data = conn.recv(4096).decode('utf-8')
                    if data:
                        response = self.process_request(data)
                        conn.send(response.encode('utf-8'))
                except Exception as e:
                    logger.error(f"Error handling request: {e}")
                finally:
                    conn.close()
        except KeyboardInterrupt:
            logger.info("Shutting down host agent")
        finally:
            server.close()
            if Path(self.socket_path).exists():
                Path(self.socket_path).unlink()

if __name__ == "__main__":
    agent = HostAgent()
    agent.run()