from fastapi import FastAPI, HTTPException, Depends, status, Request, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.responses import JSONResponse
from pydantic import BaseModel, validator
from typing import List, Optional, Dict, Any, Union
import subprocess
import json
import sqlite3
import os
import psutil
import logging
from pathlib import Path
import re
from datetime import datetime, timedelta

# Import security modules
from .security import (
    verify_password, get_password_hash, create_access_token, 
    create_refresh_token, verify_token, ACCESS_TOKEN_EXPIRE_MINUTES,
    REFRESH_TOKEN_EXPIRE_DAYS, hash_refresh_token
)
from .redis_limiter import rate_limit_login
from .host_client import host_agent
from .logging_config import setup_logging
from .audit_logger import audit_logger

# Set up logging
setup_logging()
logger = logging.getLogger("uvos")

app = FastAPI(
    title="UVOS API", 
    description="Your DIY NAS OS API", 
    version="0.3.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "https://your-domain.com"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Database setup
DB_PATH = "/var/lib/uvos/users.db"

# Models
class UserBase(BaseModel):
    username: str
    email: Optional[str] = None
    full_name: Optional[str] = None
    disabled: Optional[bool] = False
    admin: Optional[bool] = False

    @validator('username')
    def validate_username(cls, v):
        if not re.match(r'^[a-zA-Z0-9_-]{3,20}$', v):
            raise ValueError('Username must be 3-20 characters and contain only letters, numbers, underscores, and hyphens')
        return v

    @validator('email')
    def validate_email(cls, v):
        if v and not re.match(r'^[^@]+@[^@]+\.[^@]+$', v):
            raise ValueError('Invalid email format')
        return v

class UserCreate(UserBase):
    password: str

    @validator('password')
    def validate_password(cls, v):
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters long')
        return v

class User(UserBase):
    id: int
    
    class Config:
        orm_mode = True

class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str

class TokenRefresh(BaseModel):
    refresh_token: str

class SystemStats(BaseModel):
    memory: Dict[str, Any]
    cpu: Dict[str, Any]
    disks: List[Dict[str, Any]]
    network: Dict[str, Any]
    uptime: float

class StoragePoolCreate(BaseModel):
    name: str
    type: str = "stripe"
    devices: List[str]
    mountpoint: Optional[str] = None

    @validator('name')
    def validate_name(cls, v):
        if not re.match(r'^[a-zA-Z0-9_-]{1,50}$', v):
            raise ValueError('Pool name must be 1-50 characters and contain only letters, numbers, underscores, and hyphens')
        return v

class UserResponse(BaseModel):
    username: str
    email: Optional[str] = None
    full_name: Optional[str] = None
    disabled: bool
    admin: bool
    
    class Config:
        orm_mode = True

# Custom exception handlers
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    logger.warning(f"HTTP error {exc.status_code}: {exc.detail}")
    return JSONResponse(
        status_code=exc.status_code,
        content={"ok": False, "error": {"code": f"HTTP_{exc.status_code}", "message": exc.detail}}
    )

@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"ok": False, "error": {"code": "INTERNAL_ERROR", "message": "Internal server error"}}
    )

# Database initialization
def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = get_db_connection()
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users
        (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, 
         hashed_password TEXT, email TEXT, full_name TEXT, 
         disabled INTEGER, admin INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)
    ''')
    
    # Create default admin user if none exists
    c.execute("SELECT COUNT(*) FROM users WHERE admin = 1")
    if c.fetchone()[0] == 0:
        hashed_password = get_password_hash("admin123")
        c.execute(
            "INSERT INTO users (username, hashed_password, email, full_name, disabled, admin) VALUES (?, ?, ?, ?, ?, ?)",
            ("admin", hashed_password, "admin@uvos.local", "Administrator", 0, 1)
        )
        logger.info("Created default admin user")
    
    # Create refresh tokens table
    c.execute('''
        CREATE TABLE IF NOT EXISTS refresh_tokens
        (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, token TEXT,
         jti TEXT, expires_at DATETIME, revoked INTEGER DEFAULT 0,
         FOREIGN KEY(user_id) REFERENCES users(id))
    ''')
    
    # Create index for better performance
    c.execute('CREATE INDEX IF NOT EXISTS idx_refresh_jti ON refresh_tokens(jti)')
    
    conn.commit()
    conn.close()

def get_db_connection():
    """Get a database connection with WAL mode and timeout"""
    conn = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    conn.row_factory = sqlite3.Row
    return conn

def get_user(username: str):
    conn = get_db_connection()
    user = conn.execute(
        "SELECT * FROM users WHERE username = ?", (username,)
    ).fetchone()
    conn.close()
    return user

def authenticate_user(username: str, password: str):
    user = get_user(username)
    if not user:
        return False
    if not verify_password(password, user["hashed_password"]):
        return False
    return user

def create_refresh_token_db(user_id: int, token: str, jti: str, expires_at: datetime):
    """Store hashed refresh token with JTI in database"""
    token_hash = hash_refresh_token(token)
    conn = get_db_connection()
    conn.execute(
        "INSERT INTO refresh_tokens (user_id, token, jti, expires_at) VALUES (?, ?, ?, ?)",
        (user_id, token_hash, jti, expires_at)
    )
    conn.commit()
    conn.close()

def revoke_refresh_token_by_jti(jti: str):
    """Revoke a refresh token by its JTI"""
    conn = get_db_connection()
    conn.execute(
        "UPDATE refresh_tokens SET revoked = 1 WHERE jti = ?",
        (jti,)
    )
    conn.commit()
    conn.close()

def is_refresh_token_valid(token: str, jti: str = None):
    """Check if refresh token is valid by comparing hashes and JTI"""
    token_hash = hash_refresh_token(token)
    conn = get_db_connection()
    
    if jti:
        # Verify both token hash and JTI
        result = conn.execute(
            """SELECT * FROM refresh_tokens 
               WHERE token = ? AND jti = ? AND revoked = 0 AND expires_at > datetime('now')""",
            (token_hash, jti)
        ).fetchone()
    else:
        # Fallback to token hash only
        result = conn.execute(
            "SELECT * FROM refresh_tokens WHERE token = ? AND revoked = 0 AND expires_at > datetime('now')",
            (token_hash,)
        ).fetchone()
        
    conn.close()
    return result is not None

def rotate_refresh_token_db(old_jti: str, new_token_hash: str, new_jti: str, user_id: int, expires_at: datetime):
    """Atomically revoke old token and create new one"""
    conn = get_db_connection()
    try:
        # Start transaction
        conn.execute("BEGIN")
        
        # Revoke old token by jti
        conn.execute(
            "UPDATE refresh_tokens SET revoked = 1 WHERE jti = ? AND revoked = 0",
            (old_jti,)
        )
        
        # Check if any rows were affected
        if conn.total_changes == 0:
            # No token was revoked (already revoked or doesn't exist)
            conn.rollback()
            return False
        
        # Insert new token
        conn.execute(
            "INSERT INTO refresh_tokens (user_id, token, jti, expires_at) VALUES (?, ?, ?, ?)",
            (user_id, new_token_hash, new_jti, expires_at)
        )
        
        # Commit transaction
        conn.commit()
        return True
        
    except Exception as e:
        conn.rollback()
        logger.error(f"Token rotation failed: {e}")
        return False
    finally:
        conn.close()

def revoke_old_tokens(user_id: int, max_tokens: int = 5):
    """Revoke old refresh tokens, keeping only the most recent ones"""
    conn = get_db_connection()
    
    # Get token count
    count = conn.execute(
        "SELECT COUNT(*) FROM refresh_tokens WHERE user_id = ? AND revoked = 0",
        (user_id,)
    ).fetchone()[0]
    
    if count > max_tokens:
        # Get oldest tokens to revoke
        old_tokens = conn.execute(
            """SELECT jti FROM refresh_tokens 
               WHERE user_id = ? AND revoked = 0 
               ORDER BY expires_at ASC LIMIT ?""",
            (user_id, count - max_tokens)
        ).fetchall()
        
        for token_row in old_tokens:
            revoke_refresh_token_by_jti(token_row["jti"])
    
    conn.close()

# OAuth2 scheme
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="api/auth/token")

async def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    payload = verify_token(token)
    if not payload:
        raise credentials_exception
        
    username: str = payload.get("sub")
    if username is None:
        raise credentials_exception
        
    user = get_user(username)
    if user is None:
        raise credentials_exception
        
    return user

async def get_current_active_user(current_user: dict = Depends(get_current_user)):
    if current_user["disabled"]:
        raise HTTPException(status_code=400, detail="Inactive user")
    return current_user

async def require_admin_user(current_user: dict = Depends(get_current_active_user)):
    if not current_user["admin"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, 
            detail="Insufficient permissions"
        )
    return current_user

# Safe command execution with improved error handling
def run_cmd(cmd: list) -> str:
    try:
        # Log command execution (without sensitive data)
        safe_cmd = [arg for arg in cmd if not any(sensitive in arg for sensitive in ["password", "secret", "key"])]
        logger.info(f"Executing command: {' '.join(safe_cmd)}")
        
        p = subprocess.run(
            cmd, 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE, 
            text=True, 
            timeout=30,
            check=True
        )
        return p.stdout
    except subprocess.TimeoutExpired:
        logger.error(f"Command timed out: {cmd}")
        raise HTTPException(status_code=500, detail="Command execution timed out")
    except subprocess.CalledProcessError as e:
        logger.error(f"Command failed: {cmd}, stderr: {e.stderr}")
        raise HTTPException(
            status_code=500, 
            detail=f"Command failed: {e.stderr.strip() or 'Unknown error'}"
        )
    except Exception as e:
        logger.error(f"Unexpected error executing command: {cmd}, error: {e}")
        raise HTTPException(status_code=500, detail="Unexpected error executing command")

# Storage abstraction layer
class StorageManager:
    def __init__(self):
        self.drivers = {
            "zfs": ZFSDriver(),
        }
    
    def get_driver(self, fs_type="zfs"):
        return self.drivers.get(fs_type, self.drivers["zfs"])

class ZFSDriver:
    def __init__(self):
        from .host_client import host_agent
        self.agent = host_agent
    
    def list_pools(self):
        result = self.agent.send_command("zpool_list")
        if result.get("success"):
            pools = result.get("pools", [])
            for pool in pools:
                pool["type"] = "zfs"
            return pools
        else:
            logger.error(f"Failed to list ZFS pools: {result.get('error')}")
            return []
    
    def create_pool(self, name, devices, pool_type="stripe"):
        result = self.agent.send_command("zpool_create", {
            "name": name,
            "devices": devices,
            "type": pool_type
        })
        return result

# Initialize database and storage manager
storage_manager = StorageManager()
init_db()

# Auth endpoints
@app.post("/api/auth/token", response_model=Token)
async def login_for_access_token(
    request: Request,
    form_data: OAuth2PasswordRequestForm = Depends(),
    background_tasks: BackgroundTasks = None
):
    # Rate limiting
    await rate_limit_login(request)
    
    user = authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user["username"]}, 
        expires_delta=access_token_expires
    )
    
    refresh_token_expires = timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
    refresh_token, jti = create_refresh_token(
        data={"sub": user["username"]},
        expires_delta=refresh_token_expires
    )
    
    # Store refresh token in database
    expires_at = datetime.utcnow() + refresh_token_expires
    create_refresh_token_db(user["id"], refresh_token, jti, expires_at)
    
    # Revoke old refresh tokens in background
    if background_tasks:
        background_tasks.add_task(revoke_old_tokens, user["id"])
    
    return {
        "access_token": access_token, 
        "refresh_token": refresh_token,
        "token_type": "bearer"
    }

@app.post("/api/auth/refresh", response_model=Token)
async def refresh_access_token(token_data: TokenRefresh):
    refresh_token = token_data.refresh_token
    
    # Validate refresh token and extract JTI
    payload = verify_token(refresh_token, is_refresh=True)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token"
        )
    
    jti = payload.get("jti")
    username = payload.get("sub")
    
    # Validate refresh token against database
    if not is_refresh_token_valid(refresh_token, jti):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token"
        )
    
    user = get_user(username)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found"
        )
    
    # Create new tokens
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user["username"]}, 
        expires_delta=access_token_expires
    )
    
    refresh_token_expires = timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
    new_refresh_token, new_jti = create_refresh_token(
        data={"sub": user["username"]},
        expires_delta=refresh_token_expires
    )
    
    # Atomically rotate tokens
    new_token_hash = hash_refresh_token(new_refresh_token)
    expires_at = datetime.utcnow() + refresh_token_expires
    
    success = rotate_refresh_token_db(
        jti, new_token_hash, new_jti, user["id"], expires_at
    )
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token rotation failed"
        )
    
    return {
        "access_token": access_token, 
        "refresh_token": new_refresh_token,
        "token_type": "bearer"
    }

@app.post("/api/auth/logout")
async def logout(token_data: TokenRefresh, current_user: dict = Depends(get_current_active_user)):
    # Validate refresh token and extract JTI
    payload = verify_token(token_data.refresh_token, is_refresh=True)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token"
        )
    
    jti = payload.get("jti")
    revoke_refresh_token_by_jti(jti)
    
    return {"ok": True, "message": "Successfully logged out"}

# System endpoints
@app.get("/api/system/stats")
async def get_system_stats(current_user: dict = Depends(get_current_active_user)):
    """Get comprehensive system statistics"""
    try:
        # Memory info
        memory = psutil.virtual_memory()
        swap = psutil.swap_memory()
        
        # CPU info
        cpu_percent = psutil.cpu_percent(interval=1)
        cpu_times = psutil.cpu_times_percent(interval=1)
        load_avg = os.getloadavg()
        
        # Disk info
        disk_usage = psutil.disk_usage('/')
        disk_io = psutil.disk_io_counters()
        
        # Network info
        net_io = psutil.net_io_counters()
        net_if_addrs = psutil.net_if_addrs()
        
        # Uptime
        uptime = datetime.now() - datetime.fromtimestamp(psutil.boot_time())
        
        stats = {
            "memory": {
                "total": memory.total,
                "available": memory.available,
                "used": memory.used,
                "percent": memory.percent,
                "swap_total": swap.total,
                "swap_used": swap.used,
                "swap_free": swap.free
            },
            "cpu": {
                "percent": cpu_percent,
                "user": cpu_times.user,
                "system": cpu_times.system,
                "idle": cpu_times.idle,
                "load_1min": load_avg[0],
                "load_5min": load_avg[1],
                "load_15min": load_avg[2]
            },
            "disk": {
                "total": disk_usage.total,
                "used": disk_usage.used,
                "free": disk_usage.free,
                "percent": disk_usage.percent,
                "read_bytes": disk_io.read_bytes if disk_io else 0,
                "write_bytes": disk_io.write_bytes if disk_io else 0
            },
            "network": {
                "bytes_sent": net_io.bytes_sent,
                "bytes_recv": net_io.bytes_recv,
                "packets_sent": net_io.packets_sent,
                "packets_recv": net_io.packets_recv
            },
            "uptime": uptime.total_seconds()
        }
        
        return {"ok": True, "stats": stats}
    except Exception as e:
        logger.error(f"Error getting system stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/disks")
async def list_disks(current_user: dict = Depends(get_current_active_user)):
    """Return lsblk JSON (requires lsblk with -J)"""
    try:
        out = run_cmd(["lsblk", "-J", "-o", "NAME,SIZE,TYPE,MOUNTPOINT,MODEL,ROTA,Serial,UUID"])
        data = json.loads(out)
        return {"ok": True, "disks": data}
    except Exception as e:
        logger.error(f"Error listing disks: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/storage/pools")
async def list_storage_pools(current_user: dict = Depends(get_current_active_user)):
    """List all storage pools from all supported filesystems"""
    try:
        all_pools = []
        driver = ZFSDriver()
        pools = driver.list_pools()
        all_pools.extend(pools)
        
        return {"ok": True, "pools": all_pools}
    except Exception as e:
        logger.error(f"Error listing storage pools: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/storage/pools")
async def create_storage_pool(
    pool: StoragePoolCreate, 
    current_user: dict = Depends(require_admin_user)
):
    """Create a new storage pool with audit logging"""
    try:
        # Validate devices exist
        for device in pool.devices:
            if not os.path.exists(device):
                raise HTTPException(
                    status_code=400, 
                    detail=f"Device {device} does not exist"
                )
        
        # Use driver via host agent
        driver = ZFSDriver()
        result = driver.create_pool(pool.name, pool.devices, pool.type)
        
        # Log the operation
        audit_logger.log_command(
            current_user["username"],
            "zpool_create",
            {"name": pool.name, "type": pool.type, "devices_count": len(pool.devices)},
            result.get("success", False),
            result.get("error")
        )
        
        if not result.get("success", False):
            raise HTTPException(
                status_code=500, 
                detail=result.get("error", "Unknown error creating pool")
            )
        
        return {"ok": True, "message": f"Pool {pool.name} created successfully"}
    except Exception as e:
        # Log the error
        audit_logger.log_command(
            current_user["username"],
            "zpool_create",
            {"name": pool.name, "type": pool.type, "devices_count": len(pool.devices)},
            False,
            str(e)
        )
        raise

# User management endpoints
@app.get("/api/users", response_model=List[UserResponse])
async def list_users(current_user: dict = Depends(require_admin_user)):
    """List all users"""
    try:
        conn = get_db_connection()
        users = conn.execute(
            "SELECT username, email, full_name, disabled, admin FROM users ORDER BY username"
        ).fetchall()
        conn.close()
        
        return [dict(user) for user in users]
    except Exception as e:
        logger.error(f"Error listing users: {e}")
        raise HTTPException(status_code=500, detail="Failed to list users")

@app.post("/api/users", response_model=UserResponse)
async def create_user(
    user_data: UserCreate,
    current_user: dict = Depends(require_admin_user)
):
    """Create a new user"""
    try:
        conn = get_db_connection()
        
        # Check if user already exists
        existing = conn.execute(
            "SELECT COUNT(*) FROM users WHERE username = ?", (user_data.username,)
        ).fetchone()[0]
        
        if existing > 0:
            raise HTTPException(
                status_code=400, 
                detail={"message": f"User {user_data.username} already exists", "code": "USER_EXISTS"}
            )
        
        # Hash password
        hashed_password = get_password_hash(user_data.password)
        
        # Insert new user
        cursor = conn.execute(
            """INSERT INTO users (username, hashed_password, email, full_name, disabled, admin) 
               VALUES (?, ?, ?, ?, ?, ?)""",
            (user_data.username, hashed_password, user_data.email, 
             user_data.full_name, int(user_data.disabled or False), 
             int(user_data.admin or False))
        )
        
        user_id = cursor.lastrowid
        conn.commit()
        
        # Get the created user
        user = conn.execute(
            "SELECT username, email, full_name, disabled, admin FROM users WHERE id = ?",
            (user_id,)
        ).fetchone()
        
        conn.close()
        
        # Log the user creation
        audit_logger.log_command(
            current_user["username"],
            "user_create",
            {"username": user_data.username, "admin": user_data.admin, "disabled": user_data.disabled},
            True,
            None
        )
        
        return dict(user)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating user: {e}")
        
        # Log the failed user creation
        audit_logger.log_command(
            current_user["username"],
            "user_create",
            {"username": user_data.username},
            False,
            str(e)
        )
        
        raise HTTPException(status_code=500, detail={"message": "Failed to create user", "code": "USER_CREATION_FAILED"})

@app.get("/api/users/me", response_model=UserResponse)
async def read_users_me(current_user: dict = Depends(get_current_active_user)):
    """Get current user information"""
    return {
        "username": current_user["username"],
        "email": current_user["email"],
        "full_name": current_user["full_name"],
        "disabled": bool(current_user["disabled"]),
        "admin": bool(current_user["admin"])
    }

# Health endpoint
@app.get("/api/health")
async def health_check():
    """Health check endpoint for monitoring"""
    health_status = {
        "api": True,
        "database": False,
        "redis": False,
        "host_agent": False,
        "timestamp": datetime.utcnow().isoformat()
    }
    
    # Check database connection
    try:
        conn = get_db_connection()
        conn.execute("SELECT 1")
        conn.close()
        health_status["database"] = True
    except Exception as e:
        logger.error(f"Database health check failed: {e}")
    
    # Check Redis connection
    try:
        from .redis_limiter import get_redis
        redis_client = await get_redis()
        if redis_client:
            await redis_client.ping()
            health_status["redis"] = True
    except Exception as e:
        logger.error(f"Redis health check failed: {e}")
    
    # Check host agent connection
    try:
        from .host_client import host_agent
        # Try a simple command
        result = host_agent.send_command("zpool_list", {})
        health_status["host_agent"] = result.get("success", False)
    except Exception as e:
        logger.error(f"Host agent health check failed: {e}")
    
    return health_status

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        app, 
        host="0.0.0.0", 
        port=8000,
        ssl_keyfile=os.environ.get("SSL_KEYFILE"),
        ssl_certfile=os.environ.get("SSL_CERTFILE")
    )