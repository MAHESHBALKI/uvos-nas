import socket
import json
import logging
import time
import os
from pathlib import Path
from .security import generate_host_agent_token

logger = logging.getLogger("uvos")

class HostAgentClient:
    def __init__(self, socket_path="/var/run/uvos-agent.sock", secret=None):
        self.socket_path = socket_path
        self.secret = secret or os.environ.get("HOST_AGENT_SECRET")
    
    def send_command(self, command: str, params: dict = None) -> dict:
        """Send a command to the host agent with authentication"""
        if params is None:
            params = {}
        
        if not Path(self.socket_path).exists():
            return {"success": False, "error": "Host agent not available"}
        
        client = None
        try:
            # Generate authentication token with nonce
            timestamp = int(time.time())
            nonce = os.urandom(8).hex()[:16]
            auth_token = generate_host_agent_token(self.secret, timestamp, nonce) if self.secret else None
            
            # Create request
            request = {
                "command": command,
                "params": params,
                "timestamp": timestamp,
                "nonce": nonce,
                "token": auth_token
            }
            
            # Connect to socket
            client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            client.connect(self.socket_path)
            
            # Send request and receive response
            client.send(json.dumps(request).encode('utf-8'))
            response_data = client.recv(4096).decode('utf-8')
            
            # Parse response
            return json.loads(response_data)
            
        except Exception as e:
            logger.error(f"Error communicating with host agent: {e}")
            return {"success": False, "error": str(e)}
        finally:
            try:
                if client:
                    client.close()
            except:
                pass

# Global client instance
host_agent = HostAgentClient()