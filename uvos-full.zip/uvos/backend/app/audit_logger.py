import logging
import json
from datetime import datetime

class AuditLogger:
    def __init__(self, log_file="/var/log/uvos/audit.log"):
        self.logger = logging.getLogger("uvos-audit")
        self.logger.setLevel(logging.INFO)
        
        # Ensure audit log directory exists
        from pathlib import Path
        Path("/var/log/uvos").mkdir(parents=True, exist_ok=True)
        
        # File handler for audit logs
        if not self.logger.handlers:
            handler = logging.FileHandler(log_file)
            formatter = logging.Formatter('%(asctime)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
    
    def log_command(self, username: str, command: str, params: dict, success: bool, error: str = None):
        """Log a privileged command execution"""
        audit_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "username": username,
            "command": command,
            "params": self.sanitize_params(params),
            "success": success,
            "error": error
        }
        
        self.logger.info(json.dumps(audit_entry))
    
    def sanitize_params(self, params: dict) -> dict:
        """Sanitize parameters to remove sensitive information"""
        sanitized = params.copy()
        
        # Remove sensitive fields
        for key in ['token', 'password', 'secret', 'key']:
            if key in sanitized:
                sanitized[key] = '[REDACTED]'
        
        # Sanitize device paths
        if 'devices' in sanitized and isinstance(sanitized['devices'], list):
            sanitized['devices'] = ['/dev/XXX' for _ in sanitized['devices']]
        
        return sanitized

# Global audit logger instance
audit_logger = AuditLogger()