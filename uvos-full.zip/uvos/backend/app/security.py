import os
from sys import exit
from passlib.context import CryptContext
from jose import jwt, JWTError
from datetime import datetime, timedelta
import hmac
import hashlib
import logging
import uuid
import time

logger = logging.getLogger("uvos")

# Password hashing with bcrypt
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# JWT configuration - MUST be set via environment variables
SECRET_KEY = os.environ.get("SECRET_KEY")
REFRESH_SECRET_KEY = os.environ.get("REFRESH_SECRET_KEY")

# Fail fast if secrets are not set
if not SECRET_KEY or not REFRESH_SECRET_KEY:
    logger.error("FATAL: SECRET_KEY and REFRESH_SECRET_KEY must be set in environment.")
    exit(1)

ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30
REFRESH_TOKEN_EXPIRE_DAYS = 7

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire, "type": "access"})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def create_refresh_token(data: dict, expires_delta: timedelta = None):
    """Create refresh token and return both token and JTI"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
    
    # Add JTI for better revocation control
    jti = uuid.uuid4().hex
    to_encode.update({"exp": expire, "type": "refresh", "jti": jti})
    
    token = jwt.encode(to_encode, REFRESH_SECRET_KEY, algorithm=ALGORITHM)
    return token, jti

def verify_token(token: str, is_refresh: bool = False):
    secret = REFRESH_SECRET_KEY if is_refresh else SECRET_KEY
    try:
        payload = jwt.decode(
            token, 
            secret, 
            algorithms=[ALGORITHM],
            options={"leeway": 30}  # 30 seconds leeway for clock skew
        )
        
        # Validate token type
        if is_refresh and payload.get("type") != "refresh":
            raise JWTError("Invalid token type")
        if not is_refresh and payload.get("type") != "access":
            raise JWTError("Invalid token type")
            
        return payload
    except JWTError as e:
        logger.info(f"Token verification failed: {str(e)}")
        return None

def hash_refresh_token(token: str) -> str:
    """Hash refresh token using HMAC with REFRESH_SECRET_KEY"""
    return hmac.new(
        REFRESH_SECRET_KEY.encode(), 
        token.encode(), 
        hashlib.sha256
    ).hexdigest()

# Host agent HMAC helpers (for API->host-agent)
def generate_host_agent_token(secret: str, timestamp: int = None, nonce: str = None) -> str:
    """Generate HMAC token for host agent authentication with nonce"""
    if timestamp is None:
        timestamp = int(time.time())
    if nonce is None:
        nonce = uuid.uuid4().hex[:16]
    message = f"{timestamp}:{nonce}"
    return hmac.new(
        secret.encode(), 
        message.encode(), 
        hashlib.sha256
    ).hexdigest()

def verify_host_agent_token(secret: str, token: str, timestamp: int, nonce: str, max_age: int = 30) -> bool:
    """Verify HMAC token for host agent authentication with nonce"""
    # Check timestamp skew
    current_time = int(time.time())
    if abs(current_time - int(timestamp)) > max_age:
        return False
    expected = generate_host_agent_token(secret, int(timestamp), nonce)
    return hmac.compare_digest(expected, token)