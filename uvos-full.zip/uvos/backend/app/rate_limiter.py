from fastapi import Request, HTTPException
import time
from collections import defaultdict
import asyncio
import logging

logger = logging.getLogger("uvos")

# Simple in-memory rate limiter (fallback when Redis is unavailable)
class RateLimiter:
    def __init__(self, max_requests: int = 5, time_window: int = 60):
        self.max_requests = max_requests
        self.time_window = time_window
        self.requests = defaultdict(list)
        self.lock = asyncio.Lock()
        self.last_cleanup = time.time()
    
    async def is_rate_limited(self, key: str):
        async with self.lock:
            now = time.time()
            
            # Clean up old requests periodically
            if now - self.last_cleanup > 300:  # Clean up every 5 minutes
                self._cleanup_old_requests(now)
                self.last_cleanup = now
            
            # Clean up old requests for this specific key
            self.requests[key] = [t for t in self.requests[key] if now - t < self.time_window]
            
            if len(self.requests[key]) >= self.max_requests:
                return True
                
            self.requests[key].append(now)
            return False
    
    def _cleanup_old_requests(self, current_time: float):
        """Clean up requests older than the time window"""
        keys_to_delete = []
        for key, timestamps in self.requests.items():
            # Keep only recent timestamps
            self.requests[key] = [t for t in timestamps if current_time - t < self.time_window]
            
            # Mark empty keys for deletion
            if not self.requests[key]:
                keys_to_delete.append(key)
        
        # Delete empty keys
        for key in keys_to_delete:
            del self.requests[key]

# Global rate limiter instance
login_limiter = RateLimiter(max_requests=5, time_window=300)  # 5 attempts per 5 minutes

async def rate_limit_login(request: Request):
    """Rate limit login attempts using in-memory storage"""
    from .redis_limiter import get_client_ip
    client_ip = get_client_ip(request)
    if await login_limiter.is_rate_limited(f"login_{client_ip}"):
        logger.warning(f"Rate limit exceeded for IP: {client_ip}")
        raise HTTPException(
            status_code=429,
            detail="Too many login attempts. Please try again later."
        )