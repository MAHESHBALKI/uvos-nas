import logging
import sys
import re

class SensitiveDataFilter(logging.Filter):
    """Filter to remove sensitive information from logs"""
    
    def __init__(self):
        super().__init__()
        self.patterns = [
            r'(?i)password[=:]\s*[^\s,]+',
            r'(?i)token[=:]\s*[^\s,]+',
            r'(?i)secret[=:]\s*[^\s,]+',
            r'(?i)key[=:]\s*[^\s,]+',
            r'(?i)authorization:\s*bearer\s+[^\s,]+',
            r'/dev/[a-zA-Z0-9_/-]+',
            r"pool '[a-zA-Z0-9_-]+'",
            r'\d+\.\d+\.\d+\.\d+',
        ]
    
    def filter(self, record):
        if isinstance(record.msg, str):
            for pattern in self.patterns:
                record.msg = re.sub(pattern, '[REDACTED]', record.msg)
        
        if isinstance(record.args, dict):
            for key, value in record.args.items():
                if isinstance(value, str):
                    for pattern in self.patterns:
                        record.args[key] = re.sub(pattern, '[REDACTED]', value)
        elif isinstance(record.args, tuple):
            new_args = []
            for arg in record.args:
                if isinstance(arg, str):
                    for pattern in self.patterns:
                        arg = re.sub(pattern, '[REDACTED]', arg)
                new_args.append(arg)
            record.args = tuple(new_args)
        
        return True

def setup_logging():
    """Set up logging with sensitive data filtering"""
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    
    # Ensure we have at least one handler
    if not root.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        root.addHandler(handler)
    
    # Add filter to all handlers and root logger
    sensitive_filter = SensitiveDataFilter()
    for handler in root.handlers:
        handler.addFilter(sensitive_filter)
    root.addFilter(sensitive_filter)
    
    # Also configure specific loggers
    for logger_name in ['uvos', 'host-agent']:
        logger = logging.getLogger(logger_name)
        logger.setLevel(logging.INFO)
        if not logger.handlers:
            for handler in root.handlers:
                logger.addHandler(handler)
        logger.addFilter(sensitive_filter)