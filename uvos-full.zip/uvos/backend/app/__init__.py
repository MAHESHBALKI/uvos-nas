# This file makes the 'app' directory a Python package
# This allows importing between modules in the app package
# Example: from .security import verify_password

__version__ = "0.3.0"