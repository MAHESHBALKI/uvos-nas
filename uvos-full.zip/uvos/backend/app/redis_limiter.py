import redis.asyncio as redis
import time
import os
import uuid
import logging
from fastapi import Request, HTTPException

logger = logging.getLogger("uvos")

# Redis connection
_redis_client = None

def get_client_ip(request: Request) -> str:
    """Get client IP with support for proxies"""
    # Check for X-Forwarded-For header (common in proxy setups)
    xff = request.headers.get("x-forwarded-for")
    if xff:
        # Get the first IP in the chain (client IP)
        client_ip = xff.split(",")[0].strip()
        logger.debug(f"Using X-Forwarded-For IP: {client_ip}")
        return client_ip
    
    # Fall back to direct client IP
    if request.client and request.client.host:
        return request.client.host
    
    # Final fallback
    return "unknown"

async def get_redis():
    """Get a Redis connection"""
    global _redis_client
    if _redis_client is None:
        redis_url = os.environ.get("REDIS_URL", "redis://redis:6379/0")
        _redis_client = redis.from_url(redis_url, decode_responses=True)
        
        # Test connection
        try:
            await _redis_client.ping()
        except redis.RedisError as e:
            logger.error(f"Failed to connect to Redis: {e}")
            _redis_client = None
            
    return _redis_client

class RedisRateLimiter:
    def __init__(self, max_requests: int = 5, time_window: int = 60):
        self.max_requests = max_requests
        self.time_window = time_window
    
    async def is_rate_limited(self, key: str):
        """Check if request is rate limited using Redis sorted sets"""
        redis_client = await get_redis()
        
        # Fallback to in-memory if Redis is unavailable
        if redis_client is None:
            from .rate_limiter import login_limiter as fallback_limiter
            return await fallback_limiter.is_rate_limited(key)
        
        try:
            now = int(time.time())
            window_start = now - self.time_window
            
            # Generate unique member ID
            member_id = f"{now}-{uuid.uuid4().hex[:8]}"
            
            # Start a pipeline for atomic operations
            async with redis_client.pipeline() as pipe:
                # Remove old requests
                pipe.zremrangebyscore(key, 0, window_start)
                # Count current requests
                pipe.zcard(key)
                # Add current request with unique member
                pipe.zadd(key, {member_id: now})
                # Set expiration
                pipe.expire(key, self.time_window)
                
                # Execute all commands
                results = await pipe.execute()
            
            request_count = results[1]  # zcard result
            
            return request_count >= self.max_requests
                
        except redis.RedisError as e:
            logger.error(f"Redis error in rate limiting: {e}")
            # Fall back to in-memory rate limiting
            from .rate_limiter import login_limiter as fallback_limiter
            return await fallback_limiter.is_rate_limited(key)

# Global rate limiter instance
login_limiter = RedisRateLimiter(max_requests=5, time_window=300)

async def rate_limit_login(request: Request):
    client_ip = get_client_ip(request)
    if await login_limiter.is_rate_limited(f"login_{client_ip}"):
        raise HTTPException(
            status_code=429,
            detail="Too many login attempts. Please try again later."
        )

# Nonce storage helper for other code to reuse (async)
async def is_nonce_seen(nonce: str, window: int = 300) -> bool:
    redis_client = await get_redis()
    if redis_client is None:
        return False
    try:
        key = f"nonce:{nonce}"
        result = await redis_client.set(key, 1, ex=window, nx=True)
        return result is not True
    except redis.RedisError as e:
        logger.error(f"Redis error in nonce check: {e}")
        return False