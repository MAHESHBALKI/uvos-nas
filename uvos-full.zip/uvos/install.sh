#!/bin/bash

set -e

echo "Installing UVOS NAS OS..."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root"
  exit 1
fi

# Install system dependencies
echo "Installing system dependencies..."
apt-get update
apt-get install -y docker.io docker-compose python3-pip zfsutils-linux

# Create the uvos group
if ! getent group uvos >/dev/null; then
  groupadd uvos
  echo "Created group 'uvos'"
fi

# Create necessary directories
mkdir -p /var/lib/uvos /var/log/uvos /var/run
chmod 755 /var/lib/uvos /var/log/uvos

# Copy service files
cp host_agent/uvos-agent.service /etc/systemd/system/
cp host_agent/uvos-agent.socket /etc/systemd/system/

# Enable and start socket
systemctl daemon-reload
systemctl enable uvos-agent.socket
systemctl start uvos-agent.socket

echo "UVOS installation complete!"
echo "Next steps:"
echo "1. Copy .env.example to .env and edit with your secrets"
echo "2. Run 'docker-compose up -d' to start the services"
echo "3. Access the web UI at http://localhost:5173"